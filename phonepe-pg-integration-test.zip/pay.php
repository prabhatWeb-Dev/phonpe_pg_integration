
<?php
if(isset($_POST['confirm_submit_btn'])){
    // create variable post data
    $order_id = $_POST['order_id']; 
    $name= $_POST['customer_name'];
    $email= $_POST['customer_email'];
    $mobile= $_POST['mobile_no'];
    $amount = intval($_POST['recharge_amount']); // amount in INR
    $description = $_POST['description'];
    
    // Replace these with your actual PhonePe API credentials

    // create variable
    /*099eb0cd-02cf-4e2a-8aca-3e6c6aff0399*/
    $api_key= "ca990083-6597-4e8c-ac2d-08691d0610ff";
    $merchant_id= "INSTASHIPONLINE";
    $api_end_point= "/pg/v1/pay";
    $redirectUrl= "https://app.instaship.online/phonepe-pg-integration-test/pg_response.php";
    $salt_index= 1;
    // create pay load
    $sample_payload= array(
        'merchantId' => $merchant_id,
        'merchantTransactionId' => "MT7850590068188113", // test transactionID
        "merchantUserId"=>"MUID124",
        'amount' => $amount*100,
        'redirectUrl'=>$redirectUrl,
        'redirectMode'=>"POST",
        'callbackUrl'=>$redirectUrl,
        "merchantOrderId"=>$order_id,
        "mobileNumber"=>$mobile,
        "message"=>$description,
        "email"=>$email,
        "shortName"=>$name,
        "paymentInstrument"=> array(    
            "type"=> "PAY_PAGE",
      )
    );
    echo "<pre>";
    print_r($sample_payload);
    echo "</pre>";
    //convert data sample_payload into json_encode
    $json_encode= json_encode($sample_payload);
    //convert json data into base64 encode
    $pay_load_main= base64_encode($json_encode);
    //convert payload base64 data into json encode with request
    $request= json_encode(array("request"=> $pay_load_main));
    /* Here Salt Key is an api_key */
    $payload= $pay_load_main."/pg/v1/pay".$api_key;
    $sha256= hash("SHA256", $payload);
    $final_x_header= $sha256."###".$salt_index;
    /*echo $final_x_header;*/
    // initiate client URL (CURL)
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://api.phonepe.com/apis/hermes/pg/v1/pay",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $request,
        CURLOPT_HTTPHEADER => [
            "Content-Type: application/json",
            "X-VERIFY: " .$final_x_header,
            "accept: application/json"
        ],
    ]);
    $respons= curl_exec($curl);
    $error= curl_error($curl);
    curl_close($curl);

    if ($error) {
        echo "cURL Error #:" . $error;
    }else{
        $json_decode= json_decode($respons);
        if(isset($json_decode->success) && $json_decode->success== true){
            echo "<pre>";
            print_r($json_decode);
            echo "</pre>";
            $url= $json_decode->data->instrumentResponse->redirectInfo->url;
            header("Location: ".$url);
        }else{
            echo $json_decode->message;
        }
    }
    
}else{
    echo "Bad Request";
}
?>