<?php
if(isset($_POST['submit_btn'])){
    ?>
    <!doctype html>
    <html lang="en">
      <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <title>Payment Data Verify</title>
      </head>
      <body>
        <div class="container-fluid">
            <div class="container">
                <form method="post" action="pay.php">
                    <div class="row justify-content-center m-auto">
                        <div class="col-4 mt-5">
                            <div class="row justify-content-center m-auto">
                                <div class="col-12">
                                    <div class="mb-1">
                                        <input type="text" class="form-control form-control-sm" name="order_id" id="order_id" value="<?php echo $_POST['uniq_order_id'];?>" readonly>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="mb-1">
                                        <input type="text" class="form-control form-control-sm" name="customer_name" id="customer_name" value="<?php echo $_POST['customer_name'];?>" readonly>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="mb-1">
                                        <input type="text" class="form-control form-control-sm" name="customer_email" id="customer_email" value="<?php echo $_POST['customer_email'];?>" readonly>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="mb-1">
                                        <input type="text" class="form-control form-control-sm" name="mobile_no" id="mobile_no" value="<?php echo $_POST['mobile_no'];?>" readonly>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="mb-1">
                                        <input type="text" class="form-control form-control-sm" name="recharge_amount" id="recharge_amount" value="<?php echo $_POST['recharge_amount'];?>">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="mb-1">
                                        <input type="text" class="form-control form-control-sm" name="description" id="description" value="<?php echo $_POST['description'];?>" readonly>
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div class="d-grid">
                                        <input type="submit" name="confirm_submit_btn" class="btn btn-success" value="Pay Now">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
      </body>
    </html>
    <?php
}
?>