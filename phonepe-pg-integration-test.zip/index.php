<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Phonepe pg</title>
</head>
<body>
    <div class="container-fluid">
        <center>
            <h1>PhonePe Payment Gateway Integration Test</h1>
        </center>
        <form action="payment_verify.php" method="post">
            <div class="row m-auto justify-content-center">
                <div class="col-5">
                    <div class="row justify-content-center">
                        <div class="col-12">
                            <div class="mt-2">
                                <label for="OrderID" class="form-label">Uniq Order ID</label>
                                <input type="text" name="uniq_order_id" id="uniq_order_id" class="form-control" value="<?php echo uniqid(); ?>">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mt-1">
                                <label for="CustomerName" class="form-label">Customer Name</label>
                                <input type="text" name="customer_name" id="customer_name" class="form-control">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mt-1">
                                <label for="CustomerEmail" class="form-label">Customer Email</label>
                                <input type="text" name="customer_email" id="customer_email" class="form-control">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mt-1">
                                <label for="" class="form-label">Mobile No</label>
                                <input type="text" name="mobile_no" id="mobile_no" class="form-control">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mt-1">
                                <label for="" class="form-label">Amount</label>
                                <input type="text" name="recharge_amount" id="recharge_amount" class="form-control">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mt-1">
                                <label for="" class="form-label">Description</label>
                                <input type="text" name="description" id="description" class="form-control" value="Recharge For Courier Service">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mt-3">
                                <div class="d-grid">
                                    <input type="submit" name="submit_btn" class="btn btn-success" value="Recharge">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</body>
</html>